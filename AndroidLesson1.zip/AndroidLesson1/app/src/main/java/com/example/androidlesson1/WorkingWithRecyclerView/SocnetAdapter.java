package com.example.androidlesson1.WorkingWithRecyclerView;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.androidlesson1.R;

public class SocnetAdapter extends RecyclerView.Adapter<SocnetAdapter.ViewHolder> {

    private SocSource socSource;


    public SocnetAdapter(SocSource socSource) {
        this.socSource = socSource;
    }

    @NonNull
    @Override
    public SocnetAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(view);
        /*if ()*/
        return viewHolder;
    }

    @Override
    public int getItemCount() {
        return socSource.size();
    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Soc soc = socSource.getSoc(i);
        viewHolder.setData(soc.getDate(), soc.getDayOfWeek(), soc.getTemperature(),
                soc.getWeatherPicture());
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView date;
        private TextView dayOfWeek;
        private TextView temperature;
        private ImageView weatherPicture;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.date_in_item);
            dayOfWeek = itemView.findViewById(R.id.day_of_week_in_item);
            temperature = itemView.findViewById(R.id.temperature_in_item);
            weatherPicture = itemView.findViewById(R.id.weather_picture_in_item);
        }


        public void setData(String date, String dayOfWeek, String temperature, int weatherPicture) {
            getDate().setText(date);
            getDayOfWeek().setText(dayOfWeek);
            getTemperature().setText(temperature);
            getWeatherPicture().setImageResource(weatherPicture);
        }

        public TextView getDate() {
            return date;
        }

        public TextView getDayOfWeek() {
            return dayOfWeek;
        }

        public TextView getTemperature() {
            return temperature;
        }

        public ImageView getWeatherPicture() {
            return weatherPicture;
        }
    }

}
