package com.example.androidlesson1.WorkingWithFragments;

public interface PublisherGetter {

    Publisher getPublisher();
}
