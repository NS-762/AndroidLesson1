package com.example.androidlesson1;

public interface Constants {

    String CITY = "com.example.mainActivity.CITY_NAME"; // из настроек отправляется в основное активити
    String TEMPERATURE = "temperature";
    String DATE = "date";
    String DAY_OF_WEEK = "dayOfWeek";
    String WEATHER_PICTURE = "weatherPicture";

}
