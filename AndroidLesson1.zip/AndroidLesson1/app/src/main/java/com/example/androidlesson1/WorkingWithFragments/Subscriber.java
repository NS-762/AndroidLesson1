package com.example.androidlesson1.WorkingWithFragments;

public interface Subscriber {
    void updateData(String temperature, String date, String dayOfWeek);
}
